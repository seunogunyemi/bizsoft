<?php $page='about'; include "includes/header.php";?>
    <!-- about us body here -->
<div>
    <div class="container">
            <div class="row aboutUs_body">
                <div class="col-md-7">
                    <h1 class="categories">ABOUT US</h1>
                    <P>
                        Bizsoft Solutions Limited is a software development business, specialising in business applications for small, medium and large sized firms while using the latest technologies. Bizsoft Solutions Limited is a software development business, specialising in business applications for small, medium and large sized firms while using the latest technologies. Our flagship software Bizsoft HRM is an affordable, indigenous human resource management software (HRIS / HRMS) designed to help businesses manage all aspects of their human resource from a single easy to use portal.
                    </P>
                    <BR>
                        <p>
                            Bizsoft Solutions Limited is a software development business, specialising in business applications for small, medium and large sized firms while using the latest technologies. Bizsoft Solutions Limited is a software development business, specialising in business applications for small, medium and large sized firms while using the latest technologies. Our flagship software Bizsoft HRM is an affordable, indigenous human resource management software (HRIS / HRMS) designed to help businesses manage all aspects of their human resource from a single easy to use portal.
                        </p>
                        <br>
                    
                        <h1 class="categories"> MISSION</h1>
                        <p>
                            Our mission is to provide affordable, flexible and data driven business software to small, medium and large sized organisations, helping them harness the power of information technology to grow their business while delivering great value for money.
                        </p>
                </div>
                <div class="col-md-5">
                    <img class="aboutUs_img" src="img/4662.jpg">
                    <!-- <a href='https://www.freepik.com/vectors/background'>Background vector created by macrovector - www.freepik.com</a> -->
                </div>
            </div>
 
        <!-- start footer -->
        <?php include "includes/footer.php";?>