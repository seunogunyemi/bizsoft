
        
         </div>
        </div>
       
<!-- copywrite content -->
       <footer class="footer_bottom">
         <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-3" style="line-height: 0.5rem; font-size: 0.8rem;">
                            <h6>
                              <b>BIZSOFT SOLUTIONS LIMITED</b>
                            </h6>
                            <BR>
                              <p><b>Lagos Office:</b></p>
                              <br>
                              <p>117a Eti-Osa Way, Dolphin Estate</p>
                              <br>
                              <p>Lagos - Nigeria</p>
                              <br>
                              <p><b>Essex Office:</b></p>
                              <br>
                              <p>118 Elizabeth Close, Tilbury, Essex</p>
                              <br>
                              <p>RM18 8EW, United Kingdom</p>
                              <br>
                              <p>Email: questions@bizsofthrm.com</p>
                        </div>

                        <div class="col-md-6 mx-auto">
                          <i>Subscribe to our Newsletters</i><br>
                          <input class="subscribe " type="email" placeholder="enter your email address here">
                          <button class="btn btn-primary subscribeBtn">Submit</button>
                          <br>
                          <ul style="text-align: center";>
                            <li style="list-style-type: none; float:left; padding:1.3rem";>
                              <a href="index.php" style="color: black";>HOME</a>
                            </li>
                            <li style="list-style-type: none; float:left ; padding:1.3rem";>
                              <a href="aboutUs.php" style="color: black";>ABOUT US</a>
                            </li>
                            <li style="list-style-type: none; float:left ; padding:1.3rem;">
                              <a href="cloudsense.php" style="color: black";>GET CLOUDSENSE</a>
                            </li>
                            <li style="list-style-type: none; float:left; padding:1.3rem";>
                              <a href="ContactUs.php" style="color: black";>CONTACT US</a>
                            </li>
                            <li style="list-style-type: none; float:left; padding:1.3rem";>
                              <a href="#" style="color: black";>BLOG</a>
                            </li>
                          </ul>
                            
                        </div>

                        <div class="col-md-3" style="align-content: right;">
                          <p class="social_comment">Follow us on our social handles</p>
                          <br>
                          <a href="#"><img class="social_icons img-fluid" src="img/linkedIn.svg"></a>
                          <a href="#"><img class="social_icons img-fluid" src="img/facebook.svg"></a>
                          <a href="#"><img class="social_icons img-fluid last_icon" src="img/twitter.svg"></a>
                        </div>
                    </div>
            </div>
        <div class="container-fluid footer_copy">
          <div class="row" style="text-align: center; background-color: rgba(0, 0, 255, 0.055);">
            <i>copywrite BIZSOFT SOLUTIONS 2021</i>
          </div>
        </div>
      </footer>
 
      <script src="style.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>